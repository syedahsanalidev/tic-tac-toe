module.exports = {
    "RUNNING": "RUNNING",
    "X_WON": "X_WON",
    "O_WON": "O_WON",
    "DRAW": "DRAW"
};
